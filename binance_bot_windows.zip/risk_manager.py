import datetime

class RiskManager:
    def __init__(self, max_daily_loss_pct, stop_loss_pct):
        self.max_daily_loss_pct = max_daily_loss_pct
        self.stop_loss_pct = stop_loss_pct
        self.daily_start_balance = None
        self.last_reset_date = None

    def check_daily_limit(self, current_balance):
        """
        Check if the daily loss limit has been hit.
        Returns True if trading is allowed, False if halted.
        """
        today = datetime.date.today()
        
        # Reset daily baseline if it's a new day
        if self.last_reset_date != today:
            self.daily_start_balance = current_balance
            self.last_reset_date = today
            print(f"RiskManager: New day detected. Baseline balance: {self.daily_start_balance}")

        if self.daily_start_balance == 0:
            return False

        current_loss_pct = (self.daily_start_balance - current_balance) / self.daily_start_balance
        
        if current_loss_pct >= self.max_daily_loss_pct:
            print(f"CRITICAL: Daily loss limit hit ({current_loss_pct*100:.2f}%). Trading halted.")
            return False
            
        return True

    def calculate_stop_loss_price(self, side, entry_price):
        """Calculates the price for a hard stop loss."""
        if side == 'buy':
            return entry_price * (1 - self.stop_loss_pct)
        else:
            return entry_price * (1 + self.stop_loss_pct)

    def validate_slippage(self, expected_price, actual_price, max_slippage):
        """Check if slippage is within acceptable bounds."""
        slippage = abs(actual_price - expected_price) / expected_price
        return slippage <= max_slippage
