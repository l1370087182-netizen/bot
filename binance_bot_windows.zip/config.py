import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# API Configuration
BINANCE_API_KEY = os.getenv('BINANCE_API_KEY')
BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET')

# Trading Parameters
SYMBOLS = ['BTC/USDT:USDT', 'ETH/USDT:USDT']  # Target symbols for arbitrage/trend
TIMEFRAME = '30m'
LEVERAGE = 1
POSITION_SIZE_PCT = 0.05  # Use 5% of balance per trade

# Risk Management
MAX_DAILY_LOSS_PCT = 0.10  # 10% daily drawdown limit
STOP_LOSS_PCT = 0.02       # 2% hard stop loss per trade
SLIPPAGE_PROTECTION = 0.001 # 0.1% max slippage allowed

# Bot Settings
LOOP_INTERVAL = 60  # Check every 60 seconds
