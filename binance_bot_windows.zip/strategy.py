import pandas as pd
import numpy as np

class Strategy:
    def __init__(self, symbols):
        self.symbols = symbols

    def calculate_signals(self, exchange):
        """
        Detects spread regression opportunities between two correlated assets.
        For simplicity in this 30m strategy, we look at the relative price ratio.
        """
        if len(self.symbols) < 2:
            return None

        # Fetch OHLCV data for 30m timeframe
        data = {}
        for symbol in self.symbols:
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe='30m', limit=50)
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            data[symbol] = df['close']

        # Calculate Price Ratio (e.g., BTC/ETH)
        s1 = data[self.symbols[0]]
        s2 = data[self.symbols[1]]
        ratio = s1 / s2
        
        # Simple Z-Score of the ratio
        mean = ratio.rolling(window=20).mean()
        std = ratio.rolling(window=20).std()
        zscore = (ratio - mean) / std
        
        current_zscore = zscore.iloc[-1]
        
        # Mean Reversion Logic
        # If Z-score > 2: Ratio is high (S1 overpriced, S2 underpriced) -> Short S1, Long S2
        # If Z-score < -2: Ratio is low (S1 underpriced, S2 overpriced) -> Long S1, Short S2
        
        if current_zscore > 2:
            return {
                self.symbols[0]: 'sell',
                self.symbols[1]: 'buy',
                'meta': 'ratio_high'
            }
        elif current_zscore < -2:
            return {
                self.symbols[0]: 'buy',
                self.symbols[1]: 'sell',
                'meta': 'ratio_low'
            }
            
        return None
