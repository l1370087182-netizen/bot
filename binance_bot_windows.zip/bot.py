import ccxt
import time
import logging
from config import *
from strategy import Strategy
from risk_manager import RiskManager

# Logging setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class BinanceBot:
    def __init__(self):
        self.exchange = ccxt.binance({
            'apiKey': BINANCE_API_KEY,
            'secret': BINANCE_API_SECRET,
            'options': {'defaultType': 'future'},
            'enableRateLimit': True,
        })
        self.strategy = Strategy(SYMBOLS)
        self.risk = RiskManager(MAX_DAILY_LOSS_PCT, STOP_LOSS_PCT)

    def get_balance(self):
        balance = self.exchange.fetch_balance()
        return float(balance['total']['USDT'])

    def execute_trade(self, symbol, side, amount):
        try:
            # Slippage Protection: Fetch current ticker for price reference
            ticker = self.exchange.fetch_ticker(symbol)
            price = ticker['ask'] if side == 'buy' else ticker['bid']
            
            # Place Market Order
            print(f"Executing {side} for {symbol} at {price}...")
            order = self.exchange.create_market_order(symbol, side, amount)
            
            # Risk Management: Hard Stop Loss
            sl_price = self.risk.calculate_stop_loss_price(side, price)
            sl_side = 'sell' if side == 'buy' else 'buy'
            self.exchange.create_order(symbol, 'STOP_MARKET', sl_side, amount, params={'stopPrice': sl_price})
            
            print(f"Order successful. Stop Loss placed at {sl_price}")
            return order
        except Exception as e:
            print(f"Trade Execution Error: {e}")
            return None

    def run(self):
        print("Bot started. Monitoring market...")
        while True:
            try:
                # 1. Check Risk Profile
                current_balance = self.get_balance()
                if not self.risk.check_daily_limit(current_balance):
                    time.sleep(3600) # Sleep 1 hour if limit hit
                    continue

                # 2. Check Signals
                signals = self.strategy.calculate_signals(self.exchange)
                
                if signals:
                    print(f"Signal detected: {signals}")
                    # Simple Execution Logic
                    for symbol, side in signals.items():
                        if symbol == 'meta': continue
                        
                        # Calculate amount based on position size %
                        balance = self.get_balance()
                        ticker = self.exchange.fetch_ticker(symbol)
                        price = ticker['last']
                        amount = (balance * POSITION_SIZE_PCT) / price
                        
                        self.execute_trade(symbol, side, amount)
                
                time.sleep(LOOP_INTERVAL)
            except Exception as e:
                print(f"Main Loop Error: {e}")
                time.sleep(10)

if __name__ == "__main__":
    bot = BinanceBot()
    bot.run()
